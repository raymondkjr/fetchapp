package com.fetchapp.codereview

//Create data class to hold information
data class ListData(var listId: Int, var name: String, var itemID: Int) {
}